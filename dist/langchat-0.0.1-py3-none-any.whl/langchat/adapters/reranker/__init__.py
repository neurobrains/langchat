"""
Reranker adapters for document ranking.
"""

from langchat.adapters.reranker.flashrank_adapter import FlashrankRerankAdapter

__all__ = ["FlashrankRerankAdapter"]
